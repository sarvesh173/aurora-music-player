# Aurora Music Player v16.6

## v16.6 — Multi-Strategy YouTube Bot-Protection Bypass

**The problem v16.6 solves:** v16.5's `Downloader` used plain `yt-dlp` to
download audio from YouTube. YouTube applies bot-detection to many popular
videos, returning "Sign in to confirm you're not a bot" errors. v16.6 fixes
this by trying **6 different bypass strategies in sequence** until one works.

**Reverse-engineered from the 3 reference codebases:**
- **JustAnotherMusicClient** (Tauri/Rust) — SAPISIDHASH computation
  (`tauriFetch.ts` lines 92-128), 5-client-type rotation matrix
  (`lib.rs` lines 1518-1648), Innertube `/youtubei/v1/player` direct API
- **youtube-music-cli** — Invidious 3-instance fallback (`api.ts` lines
  1041-1101), yt-dlp + mpv download fallback chain (`download.service.ts`)
- **ytmdesktop** — embeds the real YTM web app (inspiration for
  cookies-from-browser strategy)

**The 6 strategies (tried in order until one succeeds):**

| # | Strategy | How it bypasses bot-detection | Config required |
|---|---|---|---|
| 1 | `yt-dlp --cookies-from-browser <browser>` | Reuses your signed-in browser session | Sign into YouTube in Firefox/Chrome/etc. |
| 2 | `yt-dlp --cookies <cookies.txt>` | Uses Netscape-format cookie file exported from a browser extension | Export cookies.txt via "Get cookies.txt LOCALLY" extension |
| 3 | `yt-dlp --extractor-args youtube:player_client=ios,android,tv,web,web_safari` | Mobile clients (iOS/Android) rarely trigger bot-detection | None |
| 4 | **Invidious API fallback** (3 instances: vid.puffyan.us, invidious.perennialte.ch, yewtu.be) | Invidious proxies the request through its own servers | None |
| 5 | **SAPISIDHASH Innertube direct API** — calls `/youtubei/v1/player` with `Authorization: SAPISIDHASH {ts}_{sha1}` + 5-client rotation (iOS → Android → TV → WEB → WEB_REMIX) | Mimics the official YouTube app's API calls | Paste your SAPISID cookie in Settings |
| 6 | Plain `yt-dlp` (no auth) | Last resort — works for non-bot-protected videos | None |

**Settings → YouTube Auth card (new in v16.6):**
- **Strategy dropdown** — Auto (try all) / Browser cookies / cookies.txt / SAPISIDHASH Innertube / No auth
- **Browser picker** — firefox / chrome / chromium / brave / edge / opera / safari / vivaldi / whale
- **cookies.txt file picker** — opens a file dialog to choose the Netscape-format cookie file
- **SAPISID cookie string field** — paste the full `Cookie:` header from your browser's devtools (must contain `SAPISID=...` or `__Secure-1PAPISID=...`)

**Status bar shows which strategy worked:** When a download succeeds, the
status bar displays `[via <strategy-name>]` so you can see at a glance which
bypass is effective on your network. Example:
`Downloaded: Never Gonna Give You Up → ~/Downloads/Rick Astley - Never Gonna Give You Up.mp3  [via client-rotation]`

**Detection logic:** The `_is_bot_blocked()` helper scans yt-dlp's stderr for
known bot-detection markers ("Sign in to confirm", "not a bot", "bot
detection", "cookies-from-browser", "Unable to extract") and immediately
falls through to the next strategy instead of waiting for the full timeout.

**CLI upgrades (v16.6):**
- `--browse-download <trackId>` — now tries all 6 strategies automatically
- `--browse-auth-status` (NEW) — prints the current YouTube auth config as JSON
- `--status` JSON's `browse` section now includes `last_strategy_used`

---

# Previous: v16.5 — Infinite Scroll + Preview Button Removed + FULL-TRACK Downloads

**Three changes from v16.0 (per user feedback):**

1. **Infinite scroll** — instead of capping results at 45-50, the Browse grid
   now loads the next page of iTunes results automatically when the user
   scrolls within 400 px of the bottom. iTunes' `offset` parameter is used
   for pagination, with a hard cap of 200 total results per query (iTunes'
   own limit). The grid shows a "↻ Loading more results…" footer while
   fetching, and a "— End of results (N shown) —" footer when iTunes runs
   out. Race-guarded so rapid scrolling doesn't fire duplicate requests.

2. **Preview button removed** — the 30-second ▶ Preview button has been
   removed from each card. Each card now has a single full-width
   **Download** button (filled primary, M3 spec). The `--browse-preview`
   CLI command is kept for backward-compat but logs a deprecation hint.

3. **Full-track downloads (not 30-second previews)** — the Downloader was
   rewritten to use **yt-dlp + ffmpeg** instead of iTunes' `previewUrl`.
   Flow:
   - iTunes provides search + metadata + artwork (still no API key).
   - When the user clicks Download, we search YouTube for `"{artist}
     {title}"` via `yt-dlp ytsearch3:`, pick the best match, download the
     audio stream, and convert to MP3 via ffmpeg (`-q:a 2` VBR ~190kbps).
   - The resulting MP3 is tagged with iTunes metadata (title / artist /
     album / genre / release date) and the 600×600 cover art is embedded
     as an APIC frame via mutagen.
   - File lands in `~/Downloads/<Artist> - <Title>.mp3`, library auto-
     rescans, tray notification fires.
   - Pre-flight checks for `yt-dlp` and `ffmpeg` with helpful install
     hints if missing.
   - Progress bar maps to phases: 0-5% YouTube search, 5-85% download,
     85-95% ffmpeg convert, 95-100% mutagen tag.

**v16.5 CLI upgrades:**
```
aurora-player --browse-load-more                    # trigger next page (infinite scroll)
aurora-player --browse-download <trackId>           # FULL-TRACK download (yt-dlp+ffmpeg -> ~/Downloads/)
aurora-player --browse-itunes <query> [country] [offset]  # paginated headless search
# --browse-preview is DEPRECATED (preview button removed in v16.5)
```
`--status` JSON's `browse` section now includes `has_more`, `loading_more`,
`last_query`, `last_country`, `max_total_results`.

---

# Previous: v16.0 — Browse feature debut

## v16.0 — Browse: Online Search + Auto-Suggestions + 30s Preview + One-Click Download

**Browse feature (reverse-engineered from JustAnotherMusicClient &
youtube-music-cli, but using the iTunes Search API for zero-config setup):**
- New **Browse** entry in the sidebar (between Library and Playlists) AND a
  prominent **external Browse button in the player bar** (always visible from
  any page — that's the "external button" one-click entry point).
- **Search iTunes** (no API key, no auth, no proxy) — 50 results per query,
  8 storefronts supported (US / IN / GB / CA / AU / DE / FR / JP).
- **Live auto-suggestions** while typing — 250 ms debounce, race-guarded so
  stale responses are discarded. Suggestions render as outlined pill chips
  that you click to instantly re-query.
- **Random suggestions on first visit** — the page auto-loads a curated seed
  query ("taylor swift", "bollywood hits", "lofi beats", …) so the grid is
  never empty on first open.
- **Result cards** — 168×168 thumbnail + title + artist + duration + genre
  chip. v16.5: single full-width Download button per card.
- **Serialized download queue** — click multiple downloads in rapid
  succession; they queue up and process one at a time so you never get
  partial files. Already-downloaded tracks are skipped (idempotent).
- **Hi-res artwork** — iTunes serves 100×100 by default; we swap the URL
  to 300×300 (and 600×600 for cover-art embedding on download).
- **Thumbnail LRU cache** — 200-entry QNetworkAccessManager-backed cache so
  scrolling the grid doesn't refetch.

**Under the hood (v16/v16.5):**
- `BrowseTrack` dataclass with `__slots__` for tight memory.
- `BrowseFetcher` / `SuggestFetcher` — QThread workers (UI never blocks).
  v16.5: `BrowseFetcher` accepts `offset` for pagination.
- `ThumbnailLoader` — async QNetworkAccessManager with LRU cache + SVG
  fallback for failed loads.
- `Downloader` — v16.5: rewritten to use yt-dlp + ffmpeg for FULL-TRACK
  downloads (was: iTunes 30-sec preview .m4a in v16.0).
- `BrowseResultCard` — self-contained QFrame; v16.5: single Download
  button (Preview button removed).
- Race-guard counters (`_browse_request_id` / `_browse_suggest_id` /
  `_browse_loading_more`) ensure stale iTunes responses are discarded.

---

# Previous: v15.0 — Playlists & Queue that actually work + Theme Studio + Beat Graph

**Playlists (fixed — you couldn't add songs before):**
- Double-click a playlist to open its detail page: rich track rows, Play,
  **Add Songs** (multi-select picker with live filter), Rename, Delete.
- Right-click any library song → **Add to playlist** (or "New playlist…").
- Remove/reorder songs inside a playlist; totals (count + duration) shown.
- Play a playlist → it loads into the queue and starts.

**Queue (fixed — you couldn't remove anything before):**
- Remove via right-click, toolbar ✕, or the **Delete** key.
- Move up / move down (now-playing highlight follows the track).
- Clear queue, **Save queue as playlist**, double-click to jump-play.
- Next/Previous now follow the queue in both directions.

**Settings page (new):**
- **Theme color slider** — drag a hue (0-359) and the entire Material 3
  dark palette regenerates live: every surface, button, slider, icon and the
  beat graph re-tint. Reset chip returns to Aurora indigo (#6366F1).
- Beat graph on/off toggle, audio output device picker, About.

**Beat graph visualizer (new, motion graphics):**
- SoundCloud-style waveform above the player bar built from the track's
  REAL peak levels (async QAudioDecoder scan, no extra dependencies).
- Bars bounce with the actual beat near the playhead, a shimmer wave travels
  through them, and the playhead dot pulses with the music.
- Click/drag the graph to seek. 30fps only while playing, pure QPainter —
  Celeron-friendly. Dancing 3-bar EQ badge marks the playing row in lists.

**Agent (CLI) upgrades:**
```
aurora-player --new-playlist <name>            # works offline too
aurora-player --add-to-playlist <name> <file>  # works offline too
aurora-player --play-playlist <name>
aurora-player --list-playlists
aurora-player --queue-file <file>              # add to end of queue
aurora-player --queue-next-file <file>         # play after current
aurora-player --queue-remove <n>               # 1-based
aurora-player --queue-clear
aurora-player --set-theme <hue 0-359>          # live retheme
```
`--status` JSON now includes queue, queue_index, playlists, theme_hue,
volume, shuffle, repeat, version.

**Bug fixes:** click anywhere on seek/volume sliders to jump (ClickSlider);
mute button actually mutes; queue view highlight stays in sync during
auto-advance; queue entries play even before the library rescan finds them.

## 📦 Debian package
Install in one line on Kali/Debian/Ubuntu:
```bash
sudo apt install ./packages/aurora-music_16.6.0_all.deb
```
Rebuild anytime with `bash packaging/build_deb.sh`. AppImage build steps:
`skill/PACKAGING_AGENT_PROMPT.md`. Runs light: native Qt, ~120–150 MB RAM —
fine on 4 GB RAM / Celeron machines. The Browse feature adds zero heavy
dependencies (just `urllib` + `QtNetwork`, both already shipped with PySide6).

---

# Previous: v14.0 — Material 3 Redesign (UI only — playback/IPC untouched)

The entire UI now implements **Google's Material 3 design system**
(m3.material.io / the Android Compose M3 spec), translated to Qt:

- **M3 color roles** — full dark scheme generated from seed `#6366F1`
  (Aurora indigo), token names mirror Compose `MaterialTheme.colorScheme`
  (`primary`, `on_primary_container`, `surface_container_high`, …).
- **Token-driven stylesheet** — one `M3` dict + `@token` substitution; zero
  hard-coded hex colors in widget code.
- **M3 components**: navigation-drawer pill items (active =
  secondary-container), FAB-shaped play button (56dp, 16dp corners,
  primary-container), standard/tonal icon buttons (40dp), full-pill search
  bar, filled + tonal buttons, M3 sliders, menus, tooltips.
- **M3 type scale** (headline-large page titles → label-small time labels).
- **State layers** — hover 8% / press 12%, precomputed for QSS.
- **Tonal elevation** — dark-theme depth via surface-container tones, no
  shadows.

New docs: `INSTALL.md` (install guide), `skill/MATERIAL3_PROMPT.md`
(agent prompt: how M3 is implemented + how to extend/re-theme).

---

# Previous: v12.2

## v12.2 — What's Fixed (player only — downloader untouched)

**Fix 1 (fatal UI bug):** The player control bar (play/pause/stop/next/seek/
volume) was never shown. `_build()` created layout `cl` on the content widget,
then tried `content.setLayout(wrap)` with a second layout — Qt rejects this
("QWidget already has a layout"), leaving the whole bar orphaned and invisible.
The user literally had no play button. The bar is now added to the existing
layout.

**Fix 2 (agent control broken):** MPRIS/playerctl commands were executed
directly on the GLib background thread. Qt objects (QMediaPlayer, widgets) are
not thread-safe — commands silently no-oped or crashed. All remote commands
(playerctl play/pause/stop/next/previous/seek/volume) are now marshalled to the
Qt main thread via a queued signal. The agent can now reliably play AND stop.

**Fix 3:** `play` with no current track used to do nothing. It now starts the
newest song in the library, so `playerctl --player=aurora play` works right
after launch.

**Also in v12.2:**
- New `aurora-player --status` prints JSON playback status (state/title/artist/
  position) — agent can check playback without playerctl.
- New `aurora-player --toggle` (play-pause) via CLI and file IPC.
- Play/pause icon now tracks the REAL playback state (flag used to drift after
  end-of-track, making the toggle button act inverted).
- Manual "next" now honors shuffle mode.
- Second `aurora-player` launch no longer clobbers the single-instance lock
  (two instances used to fight over IPC, eating agent commands).
- Scanner no longer replaced mid-run every 30s (could crash the whole app with
  "QThread destroyed while running").
- Seek bar no longer fights the user while dragging.
- Lock file cleanup only removes the lock the exiting instance owns.

---

# Previous: v12.1

Custom-built music player + downloader. No FLB. No Alger. No Electron.
Python + PySide6 + Qt Multimedia + MPRIS.

## v12.1 — What's Fixed

**Root cause fix:** `mpris_server.Server.loop()` was called with default
`background=False`, which **blocked the Qt main thread forever**. This caused
every visible symptom the user reported:

- ❌ Songs not scanning / not showing in library list
- ❌ Manual control via `playerctl` not working
- ❌ Browse / Playlists / Queue nav clicks not responding
- ❌ "Dumb loader" never finishing
- ❌ Agent couldn't trigger playback

**Fix:** `self.server.loop(background=True)` runs the GLib MainLoop in a daemon
thread, freeing Qt to run its event loop in the main thread. One-line fix,
fixes all five symptoms.

**Additional fixes:**
1. Scanner is now wrapped in try/except so the `done` signal always fires
   (prevents "Scanning..." stuck forever on permission errors).
2. `is_running()` PID check now verifies the PID actually belongs to Aurora
   via `/proc/PID/cmdline` (prevents stale-lock false positives from PID reuse).
3. `play_file()` triggers an immediate rescan when the requested file isn't
   in the library yet (handles the race where download just finished but
   Aurora's 30s timer hasn't fired).
4. `aurora_launch()` in download_song.py no longer reports "Aurora died
   immediately" when Aurora is already running and IPC returns exit code 0.
5. `smart_music_picker.py` now uses `--download-only` flag so the
   `DOWNLOADED:` stdout contract is honored (was broken in v11+).
6. `install.sh` uses `python3 -m pip` instead of bare `pip`.
7. Forced `DISPLAY=:0` no longer overrides Wayland-only sessions.

## What's in this zip

```
aurora-music-v12/
├── aurora-player/
│   ├── aurora_player.py          37KB - The music player
│   ├── install.sh                Installer
│   ├── requirements.txt          PySide6, mpris_server, mutagen
│   ├── app-icon.png              1024x1024 app icon
│   ├── icon-512.png              512x512 icon
│   ├── icon-256.png              256x256 icon
│   └── banner.png                1920x600 banner
├── skill/
│   ├── AGENT_PROMPT.md           Agent instructions (how to play songs)
│   ├── SKILL.md                  Skill metadata
│   ├── download_song.py          Downloader (JioSaavn -> SoundCloud -> YouTube)
│   ├── smart_music_picker.py     140 songs, 7 moods, weighted by YouTube history
│   └── random_songs.txt          73 curated songs
└── README.md                     This file
```

## Quick start

1. Install: `bash aurora-player/install.sh`
2. Play: `python3 skill/download_song.py "Excuses AP Dhillon"`
3. Control: `playerctl --player=aurora play/pause/next/previous`

## Features

- Auto-scans ~/Downloads/ (hardcoded, no manual setup)
- MPRIS support (playerctl works natively)
- CLI args (--play-file, --play, --pause, --next, --prev, --stop)
- Single-instance lock + IPC
- Custom SVG icons (no emojis)
- Glassmorphism UI with metallic buttons
- Search + sort library
- Playlists + queue
- Repeat + shuffle
- System tray
- Keyboard shortcuts
- Settings persistence
